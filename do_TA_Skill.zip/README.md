# Dynamic Optimization Course TA — AI Skill

An AI teaching assistant for the graduate **Dynamic Optimization** course ([apmonitor.com/do](https://apmonitor.com/do)). Install it in Claude and it turns the AI into a course-aware TA: it knows the 15-week schedule, every assignment and TCLab lab (A–H), the course's standard notation (GEKKO IMODE modes, the MHE and MPC objective forms in both squared-error and l1 dead-band variants, orthogonal collocation, the TCLab energy balances), the solver-failure triage checklist, and — most importantly — the course AI policy. It tutors, quizzes, reviews formulations, and debugs *with* you; it does not do your graded work *for* you.

## Files in this directory

| File | Purpose |
|---|---|
| [`do-course-ta.skill`](do-course-ta.skill) | The installable skill package (a zip archive containing `SKILL.md` plus two reference files: the course map and the course notes). **This is the file to install.** |
| [`skill/do-course-ta/SKILL.md`](skill/do-course-ta/SKILL.md) | The skill's main instruction file, readable here on GitHub so you can see exactly what the TA is told to do. |
| [`do-course-ta-instructions.md`](do-course-ta-instructions.md) | Portable instructions for ChatGPT Custom GPTs/Projects and Gemini Gems. |
| [`do-course-ta-knowledge.md`](do-course-ta-knowledge.md) | The combined knowledge file (course map + course notes) to upload alongside the instructions. |
| [`AGENTS.md`](AGENTS.md) / [`GEMINI.md`](GEMINI.md) | Drop-in instruction files for coding agents (Codex, Gemini CLI). |

## Install

**Claude (web or desktop app)** — recommended for most students:

1. Download [`do-course-ta.skill`](https://github.com/APMonitor/do/raw/master/TA_Skill/do-course-ta.skill).
2. In Claude, open **Settings → Capabilities → Skills** and upload the file. (Alternatively, attach the `.skill` file to a chat — if your account allows skill creation, the file card shows a **Save skill** button.)
3. Start a new conversation and ask a course question. The skill activates automatically when the topic matches; you can also invoke it by name with `/do-course-ta`.

If the Skills option is not available on your account: the `.skill` file is a zip archive. Rename it to `.zip`, extract it, and paste the contents of `SKILL.md` (plus the two files in `references/`) at the start of a conversation as context.

**ChatGPT:** create a Custom GPT or Project with `do-course-ta-instructions.md` as the instructions and `do-course-ta-knowledge.md` as a knowledge file. For Codex, copy `AGENTS.md` and the knowledge file into your working folder.

**Google Gemini:** create a Gem with the same instructions and knowledge files, or copy `GEMINI.md` into your working folder for the Gemini CLI.

**Claude Code (terminal):**

```bash
# from your home directory
mkdir -p ~/.claude/skills
cd ~/.claude/skills
curl -LO https://github.com/APMonitor/do/raw/master/TA_Skill/do-course-ta.skill
unzip do-course-ta.skill && rm do-course-ta.skill
```

This creates `~/.claude/skills/do-course-ta/`, and the skill is available in every session.

## Use

Talk to it like a TA at office hours. Examples of things it does well:

- **Concept help** — *"Why does simultaneous collocation work on an unstable reactor where shooting blows up?"*
- **Formulation review** — paste your GEKKO model and ask for an adversarial review: IMODE choice, degrees of freedom, objective placement, hard-vs-soft constraints, scaling.
- **Solver debugging** — *"IPOPT says max iterations at the 390 K setpoint step"* — it walks the course's triage checklist one hypothesis at a time instead of rewriting your code.
- **Quiz me** — *"Act as my qualifying-exam committee on MHE objectives, one question at a time, and keep a gap list."* Every assignment's Generative AI Learning section has ready-made prompts like this.
- **TCLab and GEKKO code help** — it knows the `tclab` package, the digital twin (`tclab.setup(connected=False)`), the energy balance parameters, and the IMODE table.
- **Report coaching** — bring your plots and numbers and it critiques your "What to Turn In" report, including whether your simulated-vs-measured mismatch defense actually holds.
- **Project support (weeks 7–15)** — skeptical proposal review (degrees of freedom, identifiability, scope), progress-report red-teaming, and final-report structure.

## What it will not do

The skill enforces the course AI policy, so expect it to redirect you if you ask it to:

- solve your specific graded assignment problem outright or write your report's results for you;
- answer midterm or final exam questions being taken for a grade;
- invent data, plots, solver output, or "observations" for a lab you didn't run (it will point you to the TCLab digital twin instead — real data in minutes).

You are the engineer of record for everything you submit. Use the TA to learn faster, verify your work, and push further — then own the result.

## For instructors

The skill is plain Markdown inside a zip. To adapt it for your own course: extract, edit `SKILL.md` (policy and tutoring behavior), `references/course-map.md` (schedule, links), and `references/course-notes.md` (notation and key results), then re-zip the folder and rename it `.skill`.
