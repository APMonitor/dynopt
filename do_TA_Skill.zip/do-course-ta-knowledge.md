# Dynamic Optimization Course TA - Knowledge File

Reference material for the Dynamic Optimization TA (apmonitor.com/do).
Part 1 is the course map; Part 2 is the course notes (notation, key results, misconceptions).

---

# Course Map - Dynamic Optimization (apmonitor.com/do)

Base URL for course pages: `https://apmonitor.com/do/index.php/Main/<PageName>`
Graduate course (BYU + online). GEKKO docs: https://gekko.readthedocs.io/en/latest/ · Video playlist: https://www.youtube.com/playlist?list=PLLBUgWXdTBDge70HuAhn0mlNkLB-tcbMi · GEKKO questions: https://stackoverflow.com/questions/tagged/gekko

## Schedule (week -> Topics | Assignment | TCLab / Lab)

| Week | Topic pages | Assignment | TCLab / Lab |
|---|---|---|---|
| 1 | DynamicModeling (Intro), ModelingLanguages (Basics), ModelFormulation (Formulation) | Intro - AgenticDynOpt (Dynamic Optimization with AI Assistants); A - Reservoirs (on ModelFormulation) | TCLabA - SISO Model |
| 2 | OrthogonalCollocation, ModelInitialization, ModelSimulation | B - Collocation (on OrthogonalCollocation) | TCLabB - MIMO Model |
| 3 | DynamicData, DynamicEstimation | C - Parameter Estimation (on DynamicEstimation) | TCLabC - Parameter Estimation |
| 4 | EstimatorObjective, EstimatorTuning | D - Estimator Tuning (on EstimatorTuning) | TCLabD - Empirical Model Estimation |
| 5 | EstimatorTypes (Estimation for Improved Control: bias update, KF/EKF/UKF, MHE) | E - DynamicOptimizationBenchmarks | TCLabE - Hybrid Model Estimation |
| 6 | Midterm review | Midterm Exam (MidtermExam2023; practice exams on site) | - |
| 7 | Project proposals | ProjectLab (Project Proposals) | MPC intro video (youtu.be/US_HpM_qzOg) |
| 8 | DynamicControl (MPC introduction) | F - Cruise Control (on DynamicControl); crane pendulum exercise on ControlTypes | TCLabF - Linear MPC |
| 9 | ControlTypes (MPC), NonlinearControl (NMPC), ControllerObjective | G - Linear MPC of CSTR (on NonlinearControl) | TCLabG - Nonlinear MPC |
| 10 | ControllerTuning, DiscreteVariables (MINLP) | H - Nonlinear MPC of CSTR (on NonlinearControl) | TCLabH - MHE + MPC |
| 11 | MultiObjectiveOptimization, group projects | Progress Report #1: Dynamic Model (ProjectLab) | Multi-objective and discrete control |
| 12 | Final exam review | Final Exam (FinalExam) | - |
| 13 | Project work | Progress Report #2: Estimation and Data (ProjectLab) | - |
| 14 | Project work | Progress Report #3: Control (ProjectLab) | - |
| 15 | Final presentations | Report + oral presentation (conference-manuscript format) | - |

Assignment pages double as topic pages on this course. Each assignment and TCLab page ends with a "Generative AI Learning" + "What to Turn In" block: a short PDF report (1-2 pages) with the student's own plots, formulations, multi-start evidence, and (for TCLab) a *defended* simulated-vs-measured mismatch. Students may use AI to draft but own every claim.

## Key page details

- **ModelFormulation** (Assignment A): Utah reservoir network (Jordanelle -> Deer Creek -> Utah Lake -> Great Salt Lake) - mass balances, evaporation/usage, height visualization. ~2 h.
- **OrthogonalCollocation** (Assignment B): derive collocation equations for 5 dx/dt = -x^2 + u, x(0)=0, u=4 on [0,1]; 2-6 nodes; compare with ODEINT. Analytic anchor: x(t) = 2 tanh(2t/5), x(1) ~ 0.760.
- **DynamicEstimation** (Assignment C): three problems - vehicle (estimate K, b from velocity/pedal data), exponential decay (k, staggered datasets), 3rd-order ODE (a, b, c, d).
- **EstimatorObjective**: l1 vs squared-error MHE objectives; HIV exercise (6 parameters kr1-kr6, log-scale virus data, 15 yr, global-optimality check from multiple starts).
- **EstimatorTuning** (Assignment D): estimate K, tau of a 1st-order model against simulated 1st/2nd/10th-order processes; tune for tracking vs predictive performance. Knobs: FSTATUS, STATUS, DCOST, DMAX, MEAS_GAP, horizon.
- **EstimatorTypes**: bias update vs KF/EKF/UKF vs MHE on tau dy/dt = -y + K u; MHE+MPC combined exercise.
- **DynamicOptimizationBenchmarks** (Assignment E): 6 example families / 9 exercises. 1a: min x2(tf), dx1/dt=u, dx2/dt=x1^2+u^2, x1(0)=1 (analytic optimum tanh(1) ~ 0.7616). 1b adds x1(tf)=1. 2: four coupled ODEs, -4<=u<=10. 3: tubular reactor, 0<=u<=5. 4: batch reactor A->B->C, maximize B, 298<=T<=398 (maps onto battery fast-charging). 5: catalytic reactor A<->B->C, 0<=u<=1, tf=12.
- **DynamicControl** (Assignment F): cruise control MPC, m dv/dt = -v b + K b p; m=500 kg, b=50 N-s/m, K=0.8 m/s/%pedal -> tau = m/b = 10 s, v_ss = K p (50% pedal holds 40 m/s). Competing objectives discussion.
- **ControlTypes**: MPC anatomy + overhead crane exercise (load from -1 to 0 in 6.2 s, zero final velocity and angle; repeat with 5 kg vs 1 kg payload).
- **NonlinearControl** (Assignments G, H): exothermic CSTR A->B; jacket temperature MV 250-350 K; hard limit T < 400 K; setpoints 330 -> 350 -> 370 -> 390 K; PID vs linear (ARX from step tests) MPC vs NMPC comparison. ~3 h.
- **ControllerObjective**: squared-error (reference trajectory, TAU) vs l1 deadband (SPHI/SPLO) MPC objectives; mass-damper velocity example.
- **ControllerTuning**: MV knobs (DCOST, DMAX, bounds, STATUS), CV knobs (TAU, TR_INIT, WSPHI/WSPLO, CV_TYPE), IMODE and solver choices. Exercise 1: one MV, two competing CVs with time-based priority. Exercise 2: surge tank - level (20-80%) + density (1.60 +/- 0.05 kg/L) with one MV (dilution water) under feed-density disturbances.
- **DiscreteVariables**: MINLP, branch and bound, APOPT (integer) vs IPOPT (relaxed); `m.Var(integer=True)`; thermostat/pump/feed-line examples.
- **MultiObjectiveOptimization**: ranked (lexicographic-style) l1 objectives in one solve; pressure example with safety (10-11 bar) > environmental (4-5 bar) > economic (6-7 bar) priorities; IMODE=6 demo.
- **ProjectLab**: proposal (system, diagram, 2-3 references, equations, DOF, objective, constraints, uncertainties, timeline), three progress reports (model / estimation / control), final 10-15 min presentation + conference-format report. 40+ example topics (battery storage, aquaponics, blood glucose, fuel cells, rocket ascent...).

## TCLab labs (Arduino Temperature Control Lab; overview page: AdvancedTemperatureControl)

| Page | Lab | Content |
|---|---|---|
| TCLabA | A - SISO model | Single-heater energy balance + neural net + ARX from step data |
| TCLabB | B - MIMO model | Two-heater energy balance with convective+radiative coupling; deep-learning comparison |
| TCLabC | C - Parameter estimation | Estimate U, alpha1, alpha2 from MIMO step data; batch + MHE |
| TCLabD | D - Empirical models | 1st-order, 2nd-order, ARX (`sysid`, na=nb=2); train vs validate |
| TCLabE | E - Hybrid model | Energy balance + empirical sensor lag; MHE of U, tau, alpha1, alpha2 |
| TCLabF | F - Linear MPC | 1st/2nd-order and ARX-based MPC, two setpoints |
| TCLabG | G - Nonlinear MPC | Energy-balance (and NN-hybrid) MPC on hardware |
| TCLabH | H - MHE + MPC | Adaptive: MHE (rolling ~120 s window) feeds parameters to MPC (~60 s horizon) |

Digital twin when hardware is absent: `tclab.setup(connected=False, speedup=10)` - label simulated data as simulated.
Browser apps: https://apmonitor.com/apps/tclab-sim/ (energy-balance slider fitting - labs A/B/C/E), https://apmonitor.com/apps/tclab/ (velocity-form PID baseline for MPC comparisons - labs F/G).

## Other key pages and links

- CourseSchedule, HomePage (syllabus), CourseResources, AdvancedTemperatureControl (TCLab hardware), AgenticDynOpt (week 1 AI intro assignment).
- Exams: MidtermExam2023 (+ practice variants), FinalExam. Do not answer live exam questions; practice exams are fair game after an attempt.
- Applications/benchmarks on site: inverted pendulum, rocket launch, artificial pancreas, COVID-19 response, and ~13 others - good parallel examples.
- ML/RL sections on the site (regression, sysid, LSTM, physics-informed, reinforcement learning + Gymnasium, RL on TCLab) - beyond the graded core; encourage exploration.
- Related courses: Process Dynamics and Control https://apmonitor.com/pdc (prerequisite classical control, FOPDT/IMC tuning), Machine Learning for Engineers https://apmonitor.com/pds (Agentic prompt-planning pages: AgenticWorkplan, AgenticCoding, AgenticVisualization, AgenticReports), Data-Driven Engineering https://apmonitor.com/dde.
- TA skill archive: https://github.com/APMonitor/do/tree/master/TA_Skill

---

# Course Notes - Dynamic Optimization (apmonitor.com/do)

Standard notation, key results, and misconceptions. Use these forms so tutoring matches the course website and lectures. Verify any derived number against limiting cases or analytic anchors before presenting it.

## GEKKO IMODE table (the course's central switch)

| IMODE | Class | Mode | When to use |
|---|---|---|---|
| 1 | Steady, simultaneous | Steady-state simulation | Square problem (DOF=0): check the model closes at steady state before anything dynamic |
| 2 | Steady, simultaneous | Parameter regression (MPU) | Fit parameters to one or many steady-state data points |
| 3 | Steady, simultaneous | Real-time optimization (RTO) | Steady-state economic optimization with DOF > 0 |
| 4 | Dynamic, simultaneous | Simulation | Verify dynamics on a fixed grid; produces the initialization for 5/6 |
| 5 | Dynamic, simultaneous | Moving horizon estimation (MHE) | Estimate states/parameters from a window of past data |
| 6 | Dynamic, simultaneous | Optimal control / MPC | Plan MV trajectories over a future horizon |
| 7 | Dynamic, sequential | Simulation (shooting) | Like an ODE integrator marching in time; robust for stiff, stable models with no DOF |
| 8 | Dynamic, sequential | Estimation (shooting) | Sequential analog of 5; few DOF, robustly integrable model |
| 9 | Dynamic, sequential | Control (shooting) | Sequential analog of 6 |

Rules of thumb: simultaneous (4-6) wins with many degrees of freedom, path/state constraints, or unstable dynamics (states are bounded decision variables at every node); sequential (7-9) wins when the model integrates robustly and DOF are few. Standard workflow: simulate (7 or 4) -> initialize -> estimate (5) -> control (6).

Solver selection: `m.options.SOLVER` = 1 APOPT (active set; the only one for integer/MINLP), 2 BPOPT, 3 IPOPT (interior point; default workhorse for large NLP).

## Orthogonal collocation in one paragraph

The horizon is split into finite elements; on each element the state is approximated by a low-order polynomial, and the ODE is enforced exactly at the collocation points (roots of orthogonal polynomials - Lobatto/Radau families). A collocation matrix relates state values at the nodes to their derivatives, turning each ODE into a few algebraic equations per element; the whole DAE becomes one sparse NLP solved simultaneously. `m.options.NODES` = 2-6 (nodes per element, incl. endpoints): more nodes = higher-order accuracy per element but a bigger, sometimes worse-conditioned NLP. Accuracy checks: refine nodes/elements until the answer stops moving, and compare against a sequential integration.

Course exercise anchor: 5 dx/dt = -x^2 + u, x(0)=0, u=4 has exact solution x(t) = 2 tanh(2t/5); x(1) = 2 tanh(0.4) ~ 0.7599.
Benchmark 1a anchor: min x2(tf) with dx1/dt=u, dx2/dt=x1^2+u^2, x1(0)=1, tf=1 has optimum x2(tf) = tanh(1) ~ 0.7616, x1*(t) = cosh(1-t)/cosh(1).

## MHE objective forms (as on the site: EstimatorObjective)

Squared error (l2, the Kalman-filter-adjacent form):

    min  Phi = (y_x - y)^T W_m (y_x - y) + (y - y_prior)^T W_p (y - y_prior) + Dp^T c_Dp
    s.t. 0 = f(dx/dt, x, y, p, u),  bounds and inequalities

y_x = measurements, y = model outputs, y_prior = previous model values, Dp = parameter changes.

l1-norm with dead-band (robust form; slack variables keep it smooth):

    min  Phi = w_m^T (e_U + e_L) + w_p^T (c_U + c_L) + Dp^T c_Dp
    s.t. e_U >= y - y_x - db/2,   e_L >= y_x - db/2 - y      (db = measurement dead-band)
         c_U >= y - y_prior,      c_L >= y_prior - y
         e_U, e_L, c_U, c_L >= 0

Behavior: l2 is the Gaussian MLE - one gross outlier (penalized quadratically) drags every estimate; l1 penalizes it linearly and the dead-band makes small mismatches free (noise rejection, but adds detection lag and, if db is too wide, hides real drift). The prior/Dp terms are the arrival-cost stand-in: too heavy -> estimator ignores real plant changes; too light -> estimates chatter and forget on quiet horizons. GEKKO: `m.options.EV_TYPE` = 1 (l1) or 2 (squared); measured variable `MEAS_GAP` sets db; FV/param `DCOST`/`DMAX` bound estimate movement; `FSTATUS` (0-1) feeds measurements; `STATUS` (0/1) lets the optimizer move a value.

## MPC objective forms (as on the site: ControllerObjective)

Squared error with reference trajectory (CV_TYPE=2):

    min  Phi = (y - y_t)^T W_t (y - y_t) + Du^T c_Du
    s.t. model;  tau_c * dy_t/dt + y_t = sp      (trajectory time constant tau_c = TAU)

l1 with dead-band trajectory funnel (CV_TYPE=1, industrial default):

    min  Phi = w_hi^T e_hi + w_lo^T e_lo + Du^T c_Du
    s.t. e_hi >= y - sp_hi_traj,  e_lo >= sp_lo_traj - y,  slacks >= 0

CV knobs: SP or SPHI/SPLO, TAU, TR_INIT (0 dead-band from sp; 1/2 re-center trajectory each cycle), WSP or WSPHI/WSPLO. MV knobs: DCOST (price on Du - degrades gracefully), DMAX (hard rate limit - can cause infeasibility), LOWER/UPPER, MV_STEP_HOR. Behavior: l2 chases noise inside the band (constant MV motion, actuator wear); l1 leaves the MV still while the CV is inside the funnel. TAU faster than the plant can respond just shifts error into the objective and amplifies MV moves. Move penalties also suppress model-mismatch amplification and inverse-response overreaction.

## CSTR benchmark facts (Assignments G/H)

Exothermic A->B; MV = jacket temperature T_c in [250, 350] K; hard limit T < 400 K (runaway direction); setpoint ladder 330/350/370/390 K. Process gain and speed change strongly along the ladder (Arrhenius); an ARX model identified near 330 K mispredicts near 390 K - the linear MPC degrades/oscillates there while NMPC (using the actual model) holds. Teach the hard-vs-soft constraint tradeoff on the 400 K limit: hard bound risks infeasibility under disturbance; soft (slack with heavy penalty) risks brief violations - defend the choice by failure scenario.

## Cruise control facts (Assignment F)

m dv/dt = -b v + K b p, m=500 kg, b=50 N-s/m, K=0.8 (m/s)/%pedal. tau = m/b = 10 s; v_ss = K p, so 40 m/s needs p = 50%. Horizon must comfortably exceed tau; pedal in [0,100]% saturates on hills (windup-like planning effects); competing objectives: time, speed limit, energy, Du wear, acceleration comfort.

## Crane/pendulum exercise (ControlTypes)

Move load from y=-1 to 0 in 6.2 s with zero terminal velocity AND zero terminal swing angle; then payload 1 kg -> 5 kg. Expect anti-swing counter-moves; terminal constraints shrink the feasible set; shortening the maneuver time eventually goes infeasible - soften terminal constraints or extend time.

## TCLab energy balances and standard parameters (shared with the pdc course)

Single heater (lumped, T in Kelvin for radiation):

    m c_p dT1/dt = U A (T_inf - T1) + eps sigma A (T_inf^4 - T1^4) + alpha1 Q1

Two-heater MIMO adds coupling (shared area A_s):

    m c_p dT1/dt = U A (T_inf - T1) + eps sigma A (T_inf^4 - T1^4) + Q_C12 + Q_R12 + alpha1 Q1
    m c_p dT2/dt = U A (T_inf - T2) + eps sigma A (T_inf^4 - T2^4) - Q_C12 - Q_R12 + alpha2 Q2
    Q_C12 = U A_s (T2 - T1),   Q_R12 = eps sigma A_s (T2^4 - T1^4)

Hybrid form (Lab E) adds an empirical sensor lag: tau_s dT_c/dt = T_h - T_c (measured T_c lags heater T_h).

Standard parameters: m = 0.004 kg, c_p = 500 J/kg-K, A = 1.2e-3 m^2, A_s ~ 2e-4 m^2, U ~ 4-10 W/m^2-K (fit), eps = 0.9, sigma = 5.67e-8 W/m^2-K^4, T_inf ~ 23 degC, alpha1 ~ 0.01 W/%, alpha2 ~ 0.0075 W/%. Typical FOPDT (heater 1 -> T1): K_p ~ 0.6-0.9 degC/%, tau_p ~ 120-180 s, theta_p ~ 10-25 s - question fits far outside these before tuning anything. Hardware: blue USB = data, white adapter = heater power; `pip install tclab`; digital twin `tclab.setup(connected=False, speedup=10)`; cap tests ~55-60 degC (hot to the touch).

Identifiability: from a single simultaneous step of both heaters, U and alpha are correlated (both scale the steady-state rise) - staggered/independent heater moves and ambient-return segments separate them. Estimated U absorbs unmodeled board conduction; hybrid-model U differs from Lab C's U because the sensor lag no longer contaminates it.

## FOPDT and classical tuning (bridge back to pdc)

FOPDT: tau_p dy/dt = -y + K_p u(t - theta_p). Graphical fit: K_p = Dy/Du; theta_p = delay to first response; tau_p = t(63.2% of Dy) - theta_p. IMC PI tuning (pdc standard): K_c = (1/K_p) tau_p/(theta_p + tau_c), tau_I = tau_p, with tau_c aggressive max(0.1 tau_p, 0.8 theta_p) / moderate max(1.0 tau_p, 8 theta_p) / conservative max(10 tau_p, 80 theta_p). Full derivations and PID forms: https://apmonitor.com/pdc (FirstOrderPlusDeadTime, ProportionalIntegralControl pages). In this course FOPDT mostly serves as the empirical internal model for linear MPC (Lab F/D) and the estimator structure in Assignment D.

## Solver-failure triage checklist (teach it in this order)

1. **Reproduce and read**: exact APPINFO/solver message - "infeasible" vs "max iterations" vs NaN are different diseases. `m.open_folder()` -> inspect `infeasibilities.txt` for the worst equations.
2. **Degrees of freedom**: variables - equations. Negative -> over-specified (remove an equation or free a variable); simulation should be 0; optimization > 0 via MV/FV STATUS.
3. **Bounds vs targets**: is the setpoint/terminal state reachable inside MV bounds and DMAX? Steady-state check by hand first.
4. **Initialization**: simulate first (IMODE 4/7 or COLDSTART), then optimize from that trajectory; never start an interior-point solver on/outside bounds.
5. **Hard state constraints**: soften with slack + penalty; a disturbance can make any hard state bound infeasible.
6. **Scaling and smoothness**: variables spanning orders of magnitude (log-transform), 1/x and sqrt(x) near 0, abs() -> use slack forms (m.if3, m.abs3 sparingly).
7. **Discretization**: enough nodes/elements through steep transients; but suspect conditioning before adding more.
8. **Max iterations**: raise MAX_ITER only after 1-7; also try warm start from the previous solution, or switch solver (IPOPT <-> APOPT).
9. **Integer problems**: APOPT only; check the relaxed (IPOPT) solution first - if the relaxation is infeasible, the MINLP is too.

## Common misconceptions to watch for

- **Simultaneous = repeated integration.** No: all state values are decision variables; equations hold only at convergence (infeasible-path). Intermediate iterates are not trajectories.
- **Shooting is fine for unstable plants.** Integrating an unstable mode over the horizon amplifies tiny input errors exponentially; collocation bounds states at every node.
- **More collocation nodes always help.** NLP size and conditioning grow; refine elements/nodes until the answer stops changing, then stop.
- **MHE is a Kalman filter.** KF: recursive, (linearized) Gaussian, unconstrained. MHE: windowed NLP, nonlinear model, constraints; the prior term stands in for arrival cost - wrong weight biases estimates (heavy = ignores plant changes; light = forgets/chatters). Clipping a KF estimate at a bound != constrained estimation.
- **l1 vs l2 is stylistic.** It is a noise-model choice: l2 = Gaussian MLE (outlier-fragile, noise-chasing MVs); l1 + dead-band = outlier-robust, actuator-sparing, but adds detection lag.
- **Hard constraints are safer.** A hard state bound can render the whole problem infeasible exactly when a disturbance hits; soft constraints degrade gracefully - choose per failure scenario.
- **Solver failed => problem infeasible.** Usually initialization, scaling, or DOF. Diagnose with the checklist before reformulating.
- **Good training fit => good model.** Validate on unseen data (TCLab D); more parameters always fit training better.
- **Estimates from a mismatched structure are meaningless.** A 1st-order (K, tau) fit to a 10th-order plant yields excitation-dependent but control-useful parameters - know what they absorb.
- **Rounding the relaxed MINLP solution.** Can be infeasible or far from optimal; branch and bound exists for a reason.
- **Weighted sums reach every Pareto point / encode priorities.** Nonconvex front regions are unreachable by any weights; strict priority needs ranked/lexicographic (or the site's l1-ranked) formulation.
- **Radiation in Celsius.** T^4 terms need Kelvin (TCLab and CSTR alike).
- **DMAX and DCOST are interchangeable.** DMAX is a hard rate constraint (can infeasible-ize), DCOST a price (graceful).

## Verification habits to model and demand

Units term by term; DOF count stated; limiting cases (t->0, t->inf, u->0); analytic anchors where they exist (tanh(1), 2 tanh(2/5)); multi-start before claiming a global optimum; refine the discretization until answers stop moving; and on TCLab work, hardware data is the final referee - a controller or estimator that only works in simulation is not done, and every simulated-vs-measured mismatch needs a physical defense.
